# Request 6 — Console, Cooler UI, Background GIF, Theme Customizer

## A. Theme customizer backend (the real gap)
- [ ] Inspect profile.html #themeForm fields exactly (names, defaults, reset flag)
- [ ] Implement form_section=theme handling in profile() -> preferences.theme_custom
- [ ] Handle reset flag (wipe theme_custom)
- [ ] Verify round-trip: save -> reload -> CSS vars change

## B. Console terminal
- [ ] Read console.html end-to-end (overlay, connect, socket wiring)
- [ ] Verify connect flow works against a real VPS / graceful fallback
- [ ] Redesign console chrome: status bar, toolbar, font size, copy, reconnect

## C. Cooler UI
- [ ] Add micro-interactions / polish pass on console.css + dashboard
- [ ] Verify no overflow, no contrast regressions

## D. Background image/GIF
- [ ] Confirm settings card + upload support (not just URL)
- [ ] Per-user background override in theme customizer

## E. Ship
- [ ] Restart server, screenshot all pages
- [ ] Re-zip hvm_updated.zip
- [ ] Update UPGRADE_NOTES.md
- [ ] Deliver
