# CryzonCloud / StrenoxCloud PANEL — Fix Pack (v8.0-PRO)

This build fixes the three issues you reported:

1. You could not select **Staff** or **Administrator** in the user forms.
2. Staff permissions (create VPS, delete VPS, manage users) did not actually work.
3. The LXC console showed **“[degraded console] … older agent without the PTY relay”**
   instead of a real interactive terminal.

---

## 1. Role selection now works (Create User, Edit User, Users modal)

**Cause:** `templates/admin/users_edit.html` embedded a Jinja value inside a
JavaScript string:

```js
const role = roleEl ? roleEl.value : {{ "'admin'" if user.is_admin else ... }};
```

Jinja auto-escaped the quotes to `&#39;`, the browser threw
`Uncaught SyntaxError: Unexpected token '&'`, and the entire script block died —
so the role buttons were never wired up. The Create-User modal also posted to the
wrong URL (`/admin/user/create`, singular), which 404'd.

**Fixes:**
- Replaced the unsafe expression with `{{ (...)|tojson }}`.
- Added a standalone, self-contained role-picker script to
  `users_create.html`, `users_edit.html` and `users.html` that:
  - handles mouse **and** keyboard (Enter/Space) selection,
  - sets the hidden `#role` / `#is_admin` inputs,
  - shows/hides the permission grid for Staff,
  - updates the “Summary” role label,
  - is idempotent (`data-wired`) so opening the modal twice is safe.
- Corrected the modal endpoint to `/admin/users/create`.
- Removed the old broken inline picker blocks.

Verified in a real browser: clicking **Staff** sets `role=staff`, shows the
permission grid and the label reads “Staff”; clicking **Administrator** sets
`role=admin`, `is_admin=1` and hides the grid.

---

## 2. Staff permissions are enforced end-to-end

**New permissions added to `STAFF_PERMISSIONS`:**

| Key | What it allows |
|-----|----------------|
| `vps.view` | See every VPS |
| `vps.create` | Provision a VPS for a user |
| `vps.delete` | Delete a VPS |
| `users.view` | Browse users |
| `users.create` | Create customer accounts |
| `users.edit` | Edit quotas / reset passwords |
| `users.delete` | Delete customer accounts and their VPS |
| `ports.view` | See port forwards |

**Routes re-gated:**

| Route | Before | After |
|-------|--------|-------|
| `/admin/users/create` | `@admin_required` | `@staff_permission_required('users.create')` |
| `/admin/users/<id>/edit` | `@admin_required` | `@staff_permission_required('users.edit')` |
| `/admin/users/<id>/delete` | `@admin_required` | `@staff_permission_required('users.delete')` |
| `/admin/vps` | — | `@staff_permission_required('vps.view')` |
| `/admin/vps/create` | — | `@staff_permission_required('vps.create')` |
| `/admin/vps/<id>/delete` | — | `@staff_permission_required('vps.delete')` |

**Safety guards (privilege escalation is blocked):**
- A staff member can only create **ordinary users**. If they post
  `role=admin` / `is_admin=true`, the server forces the account back to `user`.
- A staff member cannot edit or delete an **administrator** account.
- Nobody can delete the **main administrator**.
- Non-admin staff cannot change `role`, `is_admin`, `is_staff` or
  `staff_permissions` through the edit endpoint (those fields are stripped).
- UI buttons (Create / Edit / Delete) are rendered only when the current user
  actually holds the matching permission.

Verified live with a staff account: admin dashboard, VPS list, VPS create and
Users are reachable; Settings and Nodes are blocked; creating a user with
`role=admin` produces a plain user; deleting an ordinary user succeeds; deleting
the main admin is refused; deleting a VPS succeeds.

---

## 3. Real LXC PTY console (no more “degraded console”)

The panel already speaks a PTY relay (`/api/shell/open|io|resize|close`), but
older nodes run a `node.py` that predates it, so the panel fell back to
one-command-at-a-time exec mode.

**What changed:**

1. **`node.py` bumped to `3.0-PRO-ULTIMATE`** and hardened for hot upgrades:
   - accepts the legacy `--run` flag (and ignores unknown flags) so a systemd
     unit that starts `node.py --run` does not crash after an update,
   - `load_env()` now also reads `/etc/avm-node/.env`, `/etc/hvm-node/.env`,
     `/etc/node-agent/.env`, `/opt/avm-node/.env` and the real process
     environment — so a node whose key lives in a systemd `EnvironmentFile`
     still finds `API_KEY`.
2. **Panel-side self-update** (`push_node_agent_update` in `hvm.py`):
   - uploads the bundled `node.py` to the node through the agent's existing
     authenticated `/api/execute` endpoint (no SSH needed),
   - uploads in **24 KB chunks** to avoid the kernel’s ~128 KB per-argument
     limit (`Argument list too long`),
   - verifies the received size, decodes it, runs `python3 -m py_compile`,
     keeps a timestamped backup, swaps the file in and restarts
     `avm-node.service` (or signals the old PID).
3. **Automatic upgrade from the console:** when `/api/shell/open` returns 404,
   the panel no longer drops straight to exec mode. It shows
   “Automatically upgrading it now…”, pushes the new agent in a background
   thread, waits for the service to come back, retries `/api/shell/open`, and
   attaches the real PTY. Only if that fails does it fall back to the one-line
   exec shell (with a clear error message).
4. **Manual “Update agent” button** on *Admin → Nodes → node view* (main admin
   only, remote nodes only). It calls `POST /admin/nodes/<id>/update-agent` and
   reports success/failure.

Verified locally: chunk upload round-trips byte-for-byte (113,292 bytes), the
update script backs up, compiles, replaces and restarts/signals correctly, and
the new agent starts with `--run` + env-only config and exposes
`/api/shell/open` (returns a real `session_id`).

> Note: during final testing the live `node2` host itself stopped responding at
> the origin (Cloudflare **502 Bad Gateway**), so the live console could not be
> re-checked against that box. This is a host/network outage, not a code error —
> the update never reached the node (it failed while uploading). Once the node
> is reachable again, opening the console will auto-upgrade it, or you can press
> **Update agent** on the node page.

---

## Files changed

- `hvm.py`
- `node.py`
- `templates/admin/users_create.html`
- `templates/admin/users_edit.html`
- `templates/admin/users.html`
- `templates/admin/node_view.html`
- `FIXES.md` (this file)

## Deploying

1. Back up your current folder.
2. Replace the files above (or the whole `hvm/` folder).
3. Restart the panel (`systemctl restart <your-panel-service>` or
   `python3 hvm.py`).
4. The database is migrated automatically on start (`is_staff`,
   `staff_permissions` columns are added if missing).
5. For the console: open a VPS console once (auto-upgrade), or go to
   **Admin → Nodes → node2 → Update agent**.
