# Request 6 — Console, Cooler UI, Background GIF, Theme Customizer

## A. Theme customizer backend (the real gap)
- [x] Inspect profile.html #themeForm fields exactly (names, defaults, reset flag)
- [x] Implement form_section=theme handling in profile() -> preferences.theme_custom
- [x] Handle reset flag (wipe theme_custom)
- [x] Verify round-trip: save -> reload -> CSS vars change

## B. Console terminal
- [x] Read console.html end-to-end (overlay, connect, socket wiring)
- [x] Verify connect flow works against a real VPS / graceful fallback
- [x] Redesign console chrome: status bar, toolbar, font size, copy, reconnect

## C. Cooler UI
- [x] Add micro-interactions / polish pass on console.css + dashboard
- [x] Verify no overflow, no contrast regressions

## D. Background image/GIF
- [x] Confirm settings card + upload support (not just URL)
- [x] Per-user background override in theme customizer

## E. Ship
- [x] Restart server, screenshot all pages
- [x] Re-zip hvm_updated.zip
- [x] Update UPGRADE_NOTES.md
- [x] Deliver
